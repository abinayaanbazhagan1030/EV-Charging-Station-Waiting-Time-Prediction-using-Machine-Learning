# EVPulse — AI Powered EV Charging Station Analytics Dashboard

A full-stack Flask web application that turns a 10,000-row EV charging
station dataset into a live analytics dashboard, an interactive station
map, and an AI-powered waiting-time predictor.

---

## 1. Project Description

EVPulse analyzes charging events across six Indian cities (Bengaluru,
Chennai, Coimbatore, Delhi, Hyderabad, Mumbai) and answers three questions:

1. **What does the network look like right now?** — station counts,
   charger availability, fast vs. normal charging split, city-level demand.
2. **What patterns drive wait times?** — time-of-day trends, weather,
   traffic level, and feature correlations.
3. **What will happen next?** — a pre-trained Random Forest model predicts
   `Waiting_Time` (in minutes) for a given scenario, loaded from disk via
   `joblib` at request time. **The model is not retrained by the web app.**

---

## 2. Tech Stack

| Layer          | Technology                                   |
|----------------|-----------------------------------------------|
| Backend        | Python, Flask                                 |
| ML             | Pandas, NumPy, Scikit-Learn, Joblib           |
| Frontend       | HTML5, CSS3, Bootstrap 5, vanilla JavaScript  |
| Charts         | Chart.js                                      |
| Map            | Leaflet.js + OpenStreetMap tiles              |
| Icons          | Font Awesome                                  |

---

## 3. Project Structure

```
EVChargingDashboard/
│
├── app.py                  # Flask application (pages + JSON APIs)
├── check_ready.py          # Standalone readiness / smoke-test script
├── requirements.txt
├── README.md
├── model.pkl                # Trained Random Forest regressor (joblib)
├── scaler.pkl                # Fitted StandardScaler for numeric features (joblib)
├── feature_columns.pkl       # Exact training-time feature order + metadata
├── dataset.csv                # Cleaned dataset used by the app
│
├── templates/
│   ├── base.html            # Shared layout: navbar, theme toggle, footer
│   ├── index.html            # Landing page + live dashboard
│   ├── prediction.html       # ML prediction form + result
│   └── analytics.html        # Deep-dive analytics + correlation heatmap
│
├── static/
│   ├── style.css              # Design system: dark/light themes, glassmorphism
│   └── script.js              # Charts, search/table, map, prediction AJAX
│
├── models/
│   └── train_model.py         # Script that PRODUCED model.pkl / scaler.pkl
│
└── screenshots/                # (optional) put dashboard screenshots here
```

---

## 4. Installation

### 4.1 Create and activate a virtual environment

```bash
python -m venv venv

# macOS / Linux
source venv/bin/activate

# Windows
venv\Scripts\activate
```

### 4.2 Install dependencies

```bash
pip install -r requirements.txt
```

---

## 5. Running the App

```bash
python app.py
```

Then open your browser at:

```
http://127.0.0.1:5000
```

You should see the EVPulse landing page and dashboard load with live stats,
charts, and the station map. No errors, no extra setup required — the app
loads `model.pkl` and `scaler.pkl` directly.

### Optional: verify everything is ready first

```bash
python check_ready.py
```

This smoke-tests every required file, loads the model/scaler, runs a
dry-run prediction, and hits every Flask route with the test client. It
prints a PASS/FAIL summary and exits non-zero if anything is broken —
useful before a demo or deployment.

---

## 6. Dataset Details

`dataset.csv` — 10,000 rows, 18 columns, no missing values:

| Column | Description |
|---|---|
| `Station_ID` | Unique station identifier (900 unique stations) |
| `City` | Bengaluru, Chennai, Coimbatore, Delhi, Hyderabad, Mumbai |
| `Date`, `Time_Slot` | When the reading was taken |
| `Vehicle_Type` | Bike, Car, SUV, Van |
| `Battery_Percentage` | Vehicle battery level at arrival |
| `Charging_Type` | Fast / Normal |
| `Available_Chargers`, `Total_Chargers`, `Occupied_Chargers` | Charger counts |
| `Vehicles_Waiting` | Queue length |
| `Weather`, `Temperature`, `Holiday`, `Traffic_Level` | Contextual factors |
| `Electricity_Load` | Grid load at the time |
| `Charging_Power_kW` | Rated charging power |
| `Waiting_Time` | **Target variable** — minutes a vehicle waits |

> Note: this dataset does not include cost/operator/connector-type fields.
> The dashboard and prediction form were built around the columns that
> actually exist in `dataset.csv`.

---

## 7. Model Training (already done — do not re-run for the app to work)

`models/train_model.py` documents exactly how `model.pkl` and `scaler.pkl`
were produced, mirroring the original research notebook's methodology:

1. Drop `Station_ID` and `Date`.
2. Cap `Waiting_Time` outliers at 800 minutes.
3. One-hot encode categorical columns.
4. Scale numeric columns with `StandardScaler`.
5. Train and compare Linear Regression, Ridge Regression, and Random
   Forest; keep the highest-R² model.
6. Save `model.pkl`, `scaler.pkl`, and `feature_columns.pkl` with `joblib.dump`.

Result: **Random Forest**, R² ≈ 0.999 on the held-out test set.

`app.py` loads these three files once at startup with `joblib.load` and
never calls `.fit()` — every prediction is pure inference on the saved
model. If you ever want to retrain (e.g. on new data), run:

```bash
python models/train_model.py
```

This overwrites `model.pkl` / `scaler.pkl` / `feature_columns.pkl` in the
project root. The Flask app does **not** do this automatically.

---

## 8. API Reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Dashboard page |
| GET | `/prediction` | Prediction form page |
| GET | `/analytics` | Analytics / correlation page |
| GET | `/api/data?q=&page=&per_page=&sort_by=&sort_dir=` | Paginated, searchable, sortable dataset rows |
| GET | `/api/export/csv` \| `/api/export/xlsx` | Download filtered dataset |
| GET | `/api/statistics` | Summary stats, missing values, dtypes |
| GET | `/api/charts` | Pre-aggregated chart data (bar/pie/line/histogram/correlation) |
| GET | `/api/map` | One representative station per ID with map coordinates |
| POST | `/api/predict` | Predicts `Waiting_Time` from a JSON scenario payload |

---

## 9. Screenshots

Add screenshots of the running app to the `screenshots/` folder, e.g.:

- `screenshots/dashboard.png`
- `screenshots/analytics.png`
- `screenshots/prediction.png`
- `screenshots/map.png`

---

## 10. Troubleshooting

- **`ModuleNotFoundError`** → re-run `pip install -r requirements.txt` inside your active virtual environment.
- **Port already in use** → change the port in `app.py`'s `app.run(...)` call, e.g. `port=5001`.
- **Model/scaler fails to load** → confirm `model.pkl`, `scaler.pkl`, and `feature_columns.pkl` are present in the project root (run `python check_ready.py` to confirm).
