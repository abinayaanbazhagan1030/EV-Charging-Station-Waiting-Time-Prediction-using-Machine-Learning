"""
app.py
------
AI Powered EV Charging Station Analytics Dashboard

Flask backend that:
  * Serves the dashboard, prediction, and analytics pages
  * Exposes JSON APIs for the dataset, chart aggregations, statistics,
    and map data
  * Loads the ALREADY-TRAINED model.pkl + scaler.pkl (via joblib) to
    serve predictions. The model is NOT retrained here or at request
    time -- see models/train_model.py for how it was produced.

Run with:  python app.py
Then open: http://127.0.0.1:5000
"""

import hashlib
import os

import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, send_file, render_template

# --------------------------------------------------------------------------
# App & data setup
# --------------------------------------------------------------------------
app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "dataset.csv")
MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")
SCALER_PATH = os.path.join(BASE_DIR, "scaler.pkl")
FEATURES_PATH = os.path.join(BASE_DIR, "feature_columns.pkl")

# Load dataset once at startup
df = pd.read_csv(DATA_PATH)

# Load the existing trained artifacts (NOT retrained here)
model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)
feature_meta = joblib.load(FEATURES_PATH)
FEATURE_COLUMNS = feature_meta["columns"]
NUMERIC_COLS = feature_meta["numeric_cols"]
BEST_MODEL_NAME = feature_meta.get("best_model", "Random Forest")

# Approximate city center coordinates for the Leaflet map
CITY_COORDS = {
    "Bengaluru": (12.9716, 77.5946),
    "Chennai": (13.0827, 80.2707),
    "Coimbatore": (11.0168, 76.9558),
    "Delhi": (28.7041, 77.1025),
    "Hyderabad": (17.3850, 78.4867),
    "Mumbai": (19.0760, 72.8777),
}


def jitter_for_station(station_id, city):
    """Deterministic small offset per station so markers of the same
    city don't all stack on one point."""
    base_lat, base_lon = CITY_COORDS.get(city, (22.9734, 78.6569))  # India center fallback
    h = int(hashlib.md5(str(station_id).encode()).hexdigest(), 16)
    lat_off = ((h % 2000) / 2000 - 0.5) * 0.35
    lon_off = (((h // 2000) % 2000) / 2000 - 0.5) * 0.35
    return round(base_lat + lat_off, 5), round(base_lon + lon_off, 5)


# Pre-compute one representative row per station (for the map, so we
# don't plot 10,000 overlapping time-slot readings)
_station_rep = (
    df.sort_values("Waiting_Time", ascending=False)
    .drop_duplicates(subset=["Station_ID"])
    .copy()
)
_station_rep[["lat", "lon"]] = _station_rep.apply(
    lambda r: pd.Series(jitter_for_station(r["Station_ID"], r["City"])), axis=1
)

CATEGORICAL_COLS = [
    "City", "Time_Slot", "Vehicle_Type", "Charging_Type",
    "Weather", "Holiday", "Traffic_Level",
]
NUMERIC_INPUT_COLS = [
    "Battery_Percentage", "Available_Chargers", "Vehicles_Waiting",
    "Temperature", "Electricity_Load", "Total_Chargers",
    "Occupied_Chargers", "Charging_Power_kW",
]


# --------------------------------------------------------------------------
# Page routes
# --------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/prediction")
def prediction_page():
    options = {col: sorted(df[col].dropna().unique().tolist()) for col in CATEGORICAL_COLS}
    ranges = {
        col: {"min": int(df[col].min()), "max": int(df[col].max()), "mean": round(float(df[col].mean()), 1)}
        for col in NUMERIC_INPUT_COLS
    }
    return render_template("prediction.html", options=options, ranges=ranges, model_name=BEST_MODEL_NAME)


@app.route("/analytics")
def analytics_page():
    return render_template("analytics.html")


# --------------------------------------------------------------------------
# API: dataset (table + live search + pagination)
# --------------------------------------------------------------------------
@app.route("/api/data")
def api_data():
    search = request.args.get("q", "").strip().lower()
    page = max(int(request.args.get("page", 1)), 1)
    per_page = min(max(int(request.args.get("per_page", 25)), 1), 500)
    sort_by = request.args.get("sort_by", "Station_ID")
    sort_dir = request.args.get("sort_dir", "asc")

    filtered = df
    if search:
        search_cols = ["Station_ID", "City", "Vehicle_Type", "Charging_Type"]
        mask = pd.Series(False, index=filtered.index)
        for col in search_cols:
            mask = mask | filtered[col].astype(str).str.lower().str.contains(search, na=False)
        filtered = filtered[mask]

    if sort_by in filtered.columns:
        filtered = filtered.sort_values(sort_by, ascending=(sort_dir == "asc"))

    total = len(filtered)
    start = (page - 1) * per_page
    end = start + per_page
    page_df = filtered.iloc[start:end]

    return jsonify({
        "total": total,
        "page": page,
        "per_page": per_page,
        "total_pages": max((total + per_page - 1) // per_page, 1),
        "rows": page_df.to_dict(orient="records"),
    })


@app.route("/api/export/<fmt>")
def api_export(fmt):
    search = request.args.get("q", "").strip().lower()
    filtered = df
    if search:
        search_cols = ["Station_ID", "City", "Vehicle_Type", "Charging_Type"]
        mask = pd.Series(False, index=filtered.index)
        for col in search_cols:
            mask = mask | filtered[col].astype(str).str.lower().str.contains(search, na=False)
        filtered = filtered[mask]

    out_path = os.path.join(BASE_DIR, f"export_temp.{fmt}")
    if fmt == "csv":
        filtered.to_csv(out_path, index=False)
        return send_file(out_path, as_attachment=True, download_name="ev_charging_data.csv")
    elif fmt == "xlsx":
        filtered.to_excel(out_path, index=False)
        return send_file(out_path, as_attachment=True, download_name="ev_charging_data.xlsx")
    return jsonify({"error": "Unsupported format"}), 400


# --------------------------------------------------------------------------
# API: summary statistics
# --------------------------------------------------------------------------
@app.route("/api/statistics")
def api_statistics():
    total_stations = int(df["Station_ID"].nunique())
    total_cities = int(df["City"].nunique())
    avg_waiting_time = round(float(df["Waiting_Time"].mean()), 1)
    avg_battery = round(float(df["Battery_Percentage"].mean()), 1)
    avg_available_chargers = round(float(df["Available_Chargers"].mean()), 1)
    fast_count = int((df["Charging_Type"] == "Fast").sum())
    normal_count = int((df["Charging_Type"] == "Normal").sum())
    avg_power = round(float(df["Charging_Power_kW"].mean()), 1)
    avg_load = round(float(df["Electricity_Load"].mean()), 1)

    missing = df.isnull().sum()
    missing_values = {k: int(v) for k, v in missing.items() if v > 0}
    duplicates = int(df.duplicated().sum())

    return jsonify({
        "total_records": int(len(df)),
        "total_stations": total_stations,
        "total_cities": total_cities,
        "avg_waiting_time": avg_waiting_time,
        "avg_battery_percentage": avg_battery,
        "avg_available_chargers": avg_available_chargers,
        "fast_charging_count": fast_count,
        "slow_charging_count": normal_count,
        "avg_charging_power_kw": avg_power,
        "avg_electricity_load": avg_load,
        "missing_values": missing_values,
        "duplicate_rows": duplicates,
        "dtypes": {k: str(v) for k, v in df.dtypes.items()},
    })


# --------------------------------------------------------------------------
# API: chart-ready aggregations
# --------------------------------------------------------------------------
@app.route("/api/charts")
def api_charts():
    # Charging type split (pie/doughnut)
    charging_type = df["Charging_Type"].value_counts().to_dict()

    # Stations per city (bar)
    stations_per_city = (
        df.groupby("City")["Station_ID"].nunique().sort_values(ascending=False).to_dict()
    )

    # Avg waiting time per city (horizontal bar)
    waiting_by_city = df.groupby("City")["Waiting_Time"].mean().round(1).sort_values(ascending=False).to_dict()

    # Avg waiting time by time slot (line/area)
    slot_order = ["Morning", "Afternoon", "Evening", "Night"]
    waiting_by_slot = df.groupby("Time_Slot")["Waiting_Time"].mean().round(1).reindex(slot_order).to_dict()

    # Vehicle type distribution (doughnut)
    vehicle_type = df["Vehicle_Type"].value_counts().to_dict()

    # Traffic level distribution (radar-friendly)
    traffic_level = df["Traffic_Level"].value_counts().to_dict()

    # Weather distribution
    weather_dist = df["Weather"].value_counts().to_dict()

    # Waiting time histogram
    counts, bin_edges = np.histogram(df["Waiting_Time"], bins=12)
    histogram = {
        "labels": [f"{int(bin_edges[i])}-{int(bin_edges[i+1])}" for i in range(len(counts))],
        "values": counts.tolist(),
    }

    # Correlation matrix (heatmap) on numeric columns
    numeric_df = df[NUMERIC_INPUT_COLS + ["Waiting_Time"]]
    corr = numeric_df.corr().round(2)
    correlation = {
        "labels": corr.columns.tolist(),
        "matrix": corr.values.tolist(),
    }

    # Top 10 busiest stations by avg waiting time (min 3 readings)
    station_stats = df.groupby("Station_ID").agg(
        avg_wait=("Waiting_Time", "mean"), city=("City", "first"), n=("Waiting_Time", "size")
    )
    top_stations = (
        station_stats[station_stats["n"] >= 3]
        .sort_values("avg_wait", ascending=False)
        .head(10)
        .reset_index()
    )
    top_stations["avg_wait"] = top_stations["avg_wait"].round(1)

    return jsonify({
        "charging_type": charging_type,
        "stations_per_city": stations_per_city,
        "waiting_by_city": waiting_by_city,
        "waiting_by_slot": waiting_by_slot,
        "vehicle_type": vehicle_type,
        "traffic_level": traffic_level,
        "weather_dist": weather_dist,
        "histogram": histogram,
        "correlation": correlation,
        "top_stations": top_stations.to_dict(orient="records"),
    })


# --------------------------------------------------------------------------
# API: map data
# --------------------------------------------------------------------------
@app.route("/api/map")
def api_map():
    records = _station_rep[[
        "Station_ID", "City", "Charging_Type", "Available_Chargers",
        "Total_Chargers", "Vehicle_Type", "Waiting_Time", "lat", "lon",
    ]].to_dict(orient="records")
    return jsonify({"stations": records})


# --------------------------------------------------------------------------
# API: prediction (uses the pre-trained model.pkl / scaler.pkl ONLY)
# --------------------------------------------------------------------------
@app.route("/api/predict", methods=["POST"])
def api_predict():
    payload = request.get_json(force=True)

    try:
        row = {}
        for col in NUMERIC_INPUT_COLS:
            row[col] = float(payload.get(col))
        for col in CATEGORICAL_COLS:
            row[col] = payload.get(col)
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid or missing input values."}), 400

    input_df = pd.DataFrame([row])
    input_encoded = pd.get_dummies(input_df)

    # Align to the exact feature columns the model was trained on
    input_aligned = input_encoded.reindex(columns=FEATURE_COLUMNS, fill_value=0)

    # Scale numeric columns using the SAVED scaler (no re-fitting)
    input_aligned[NUMERIC_COLS] = scaler.transform(input_aligned[NUMERIC_COLS])

    prediction = float(model.predict(input_aligned)[0])
    prediction = max(prediction, 0)

    # Confidence score: derived from agreement across the forest's trees
    if hasattr(model, "estimators_"):
        tree_preds = np.array([t.predict(input_aligned)[0] for t in model.estimators_])
        spread = tree_preds.std()
        # Convert spread into a 0-100 confidence score (tighter spread = higher confidence)
        confidence = float(max(0, min(100, 100 - (spread / (prediction + 1e-6)) * 100)))
    else:
        confidence = 80.0

    if prediction < 60:
        demand_level = "Low"
    elif prediction < 150:
        demand_level = "Medium"
    else:
        demand_level = "High"

    return jsonify({
        "predicted_waiting_time": round(prediction, 1),
        "demand_level": demand_level,
        "confidence_score": round(confidence, 1),
        "model_used": BEST_MODEL_NAME,
    })


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
