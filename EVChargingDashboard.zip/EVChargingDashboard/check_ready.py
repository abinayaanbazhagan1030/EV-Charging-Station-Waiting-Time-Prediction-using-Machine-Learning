"""
check_ready.py
--------------
Readiness check for the EV Charging Station Analytics Dashboard.

Run this BEFORE `python app.py` to confirm the project was built/processed
successfully: required files exist, the saved model/scaler load correctly,
the dataset is readable, and (optionally) the Flask app's core routes
respond. Prints a PASS/FAIL summary and exits non-zero on failure so it
can be used in CI as well.

Usage:
    python check_ready.py
"""

import importlib.util
import os
import sys
import traceback

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

REQUIRED_FILES = [
    "app.py",
    "requirements.txt",
    "dataset.csv",
    "model.pkl",
    "scaler.pkl",
    "feature_columns.pkl",
    os.path.join("templates", "base.html"),
    os.path.join("templates", "index.html"),
    os.path.join("templates", "prediction.html"),
    os.path.join("templates", "analytics.html"),
    os.path.join("static", "style.css"),
    os.path.join("static", "script.js"),
    os.path.join("models", "train_model.py"),
]

results = []  # (check_name, ok: bool, detail: str)


def record(name, ok, detail=""):
    results.append((name, ok, detail))
    status = "PASS" if ok else "FAIL"
    print(f"[{status}] {name}" + (f" — {detail}" if detail else ""))


# --------------------------------------------------------------------------
# 1. File presence
# --------------------------------------------------------------------------
print("\n=== 1. Required files ===")
for rel_path in REQUIRED_FILES:
    full_path = os.path.join(BASE_DIR, rel_path)
    record(f"File exists: {rel_path}", os.path.isfile(full_path))

# --------------------------------------------------------------------------
# 2. Dataset loads and has expected shape/columns
# --------------------------------------------------------------------------
print("\n=== 2. Dataset integrity ===")
try:
    import pandas as pd
    df = pd.read_csv(os.path.join(BASE_DIR, "dataset.csv"))
    record("dataset.csv loads with pandas", True, f"{df.shape[0]} rows x {df.shape[1]} cols")

    expected_cols = {
        "Station_ID", "City", "Date", "Time_Slot", "Vehicle_Type",
        "Battery_Percentage", "Charging_Type", "Available_Chargers",
        "Vehicles_Waiting", "Weather", "Temperature", "Holiday",
        "Electricity_Load", "Waiting_Time", "Total_Chargers",
        "Occupied_Chargers", "Charging_Power_kW", "Traffic_Level",
    }
    missing_cols = expected_cols - set(df.columns)
    record("All expected columns present", len(missing_cols) == 0,
           f"missing: {missing_cols}" if missing_cols else "")

    record("No unexpected nulls in target (Waiting_Time)",
           df["Waiting_Time"].isnull().sum() == 0)
except Exception as e:
    record("dataset.csv loads with pandas", False, str(e))

# --------------------------------------------------------------------------
# 3. Model artifacts load via joblib and are internally consistent
# --------------------------------------------------------------------------
print("\n=== 3. Model artifacts (joblib) ===")
try:
    import joblib
    model = joblib.load(os.path.join(BASE_DIR, "model.pkl"))
    scaler = joblib.load(os.path.join(BASE_DIR, "scaler.pkl"))
    feature_meta = joblib.load(os.path.join(BASE_DIR, "feature_columns.pkl"))

    record("model.pkl loads", True, type(model).__name__)
    record("scaler.pkl loads", True, type(scaler).__name__)
    record("feature_columns.pkl loads", True, f"{len(feature_meta.get('columns', []))} features")

    has_predict = hasattr(model, "predict")
    record("Loaded model exposes .predict()", has_predict)

    numeric_cols = feature_meta.get("numeric_cols", [])
    record("Scaler numeric columns recorded", len(numeric_cols) > 0, f"{numeric_cols}")

    # End-to-end dry-run prediction using the mean of every numeric field
    # and the first category of every categorical field.
    import pandas as pd
    df = pd.read_csv(os.path.join(BASE_DIR, "dataset.csv"))
    categorical_cols = ["City", "Time_Slot", "Vehicle_Type", "Charging_Type",
                         "Weather", "Holiday", "Traffic_Level"]
    row = {c: float(df[c].mean()) for c in numeric_cols}
    row.update({c: df[c].dropna().iloc[0] for c in categorical_cols})

    input_df = pd.DataFrame([row])
    input_encoded = pd.get_dummies(input_df)
    input_aligned = input_encoded.reindex(columns=feature_meta["columns"], fill_value=0)
    input_aligned[numeric_cols] = scaler.transform(input_aligned[numeric_cols])
    pred = model.predict(input_aligned)[0]

    record("End-to-end dry-run prediction succeeds", True, f"predicted Waiting_Time = {pred:.1f} min")
except Exception as e:
    record("Model artifacts load & predict", False, f"{e}\n{traceback.format_exc(limit=2)}")

# --------------------------------------------------------------------------
# 4. app.py imports cleanly and exposes the expected Flask routes
# --------------------------------------------------------------------------
print("\n=== 4. Flask app import & routes ===")
try:
    spec = importlib.util.spec_from_file_location("app", os.path.join(BASE_DIR, "app.py"))
    app_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(app_module)
    flask_app = app_module.app
    record("app.py imports without errors", True)

    rules = {r.rule for r in flask_app.url_map.iter_rules()}
    expected_routes = ["/", "/prediction", "/analytics",
                        "/api/data", "/api/charts", "/api/statistics",
                        "/api/map", "/api/predict", "/api/export/<fmt>"]
    for route in expected_routes:
        record(f"Route registered: {route}", route in rules)

    # Use Flask's test client to actually hit each page/API once.
    client = flask_app.test_client()
    for route, method in [
        ("/", "GET"), ("/prediction", "GET"), ("/analytics", "GET"),
        ("/api/data", "GET"), ("/api/charts", "GET"),
        ("/api/statistics", "GET"), ("/api/map", "GET"),
    ]:
        resp = client.get(route)
        record(f"{method} {route} returns 200", resp.status_code == 200, f"status={resp.status_code}")

    predict_payload = {
        "Battery_Percentage": 50, "Available_Chargers": 4, "Vehicles_Waiting": 10,
        "Temperature": 28, "Electricity_Load": 60, "Total_Chargers": 6,
        "Occupied_Chargers": 2, "Charging_Power_kW": 100,
        "City": "Coimbatore", "Time_Slot": "Morning", "Vehicle_Type": "Car",
        "Charging_Type": "Fast", "Weather": "Sunny", "Holiday": "No", "Traffic_Level": "Medium",
    }
    resp = client.post("/api/predict", json=predict_payload)
    ok = resp.status_code == 200 and "predicted_waiting_time" in resp.get_json()
    record("POST /api/predict returns a prediction", ok, resp.get_json())
except Exception as e:
    record("app.py imports & routes respond", False, f"{e}\n{traceback.format_exc(limit=2)}")

# --------------------------------------------------------------------------
# Summary
# --------------------------------------------------------------------------
print("\n=== Summary ===")
total = len(results)
passed = sum(1 for _, ok, _ in results if ok)
failed = [name for name, ok, _ in results if not ok]

print(f"{passed}/{total} checks passed.")
if failed:
    print("\nFailed checks:")
    for name in failed:
        print(f"  - {name}")
    print("\nRESULT: NOT READY — fix the failures above before running app.py")
    sys.exit(1)
else:
    print("\nRESULT: READY — the app processed successfully. Run: python app.py")
    sys.exit(0)
