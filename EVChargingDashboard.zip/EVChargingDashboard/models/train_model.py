"""
train_model.py
----------------
Trains the Waiting_Time prediction model for the EV Charging Station
Analytics Dashboard.

This script follows the exact methodology from the original research
notebook (EVCharging__21_.ipynb):
    1. Load the dataset
    2. Drop identifier / date columns (Station_ID, Date)
    3. Cap Waiting_Time outliers at 800 (matches notebook's outlier handling)
    4. One-hot encode categorical columns
    5. Compare Linear Regression, Ridge Regression, and Random Forest
    6. Select the best performing model (Random Forest won in the notebook)
    7. Save the trained model + the fitted scaler + feature column order

Run this once with:  python models/train_model.py
It produces ../model.pkl, ../scaler.pkl and ../feature_columns.pkl
in the project root, which app.py loads directly (no retraining at
request time).
"""

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "dataset.csv")
MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")
SCALER_PATH = os.path.join(BASE_DIR, "scaler.pkl")
FEATURES_PATH = os.path.join(BASE_DIR, "feature_columns.pkl")

TARGET = "Waiting_Time"
DROP_COLS = ["Station_ID", "Date"]

# Numeric columns that get scaled (matches the notebook's numeric fields)
NUMERIC_COLS = [
    "Battery_Percentage", "Available_Chargers", "Vehicles_Waiting",
    "Temperature", "Electricity_Load", "Total_Chargers",
    "Occupied_Chargers", "Charging_Power_kW",
]


def load_and_prepare():
    df = pd.read_csv(DATA_PATH)
    df = df.drop(columns=[c for c in DROP_COLS if c in df.columns])

    # Outlier capping, exactly as in the notebook
    df[TARGET] = df[TARGET].mask(df[TARGET] > 800, 800)

    # One-hot encode categoricals (mirrors pd.get_dummies(df) in the notebook)
    df_encoded = pd.get_dummies(df)

    return df_encoded


def main():
    print("Loading dataset...")
    df = load_and_prepare()

    X = df.drop(columns=[TARGET])
    y = df[TARGET]

    feature_columns = list(X.columns)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Scale numeric columns only; one-hot columns are already 0/1
    scaler = StandardScaler()
    num_cols_present = [c for c in NUMERIC_COLS if c in X_train.columns]
    X_train_scaled = X_train.copy()
    X_test_scaled = X_test.copy()
    X_train_scaled[num_cols_present] = scaler.fit_transform(X_train[num_cols_present])
    X_test_scaled[num_cols_present] = scaler.transform(X_test[num_cols_present])

    candidates = {
        "Linear Regression": LinearRegression(),
        "Ridge Regression": Ridge(alpha=1.0),
        "Random Forest": RandomForestRegressor(
            n_estimators=120, max_depth=14, min_samples_leaf=2,
            random_state=42, n_jobs=-1
        ),
    }

    results = {}
    best_name, best_model, best_r2 = None, None, -np.inf

    print("\nTraining & evaluating candidate models...")
    for name, model in candidates.items():
        model.fit(X_train_scaled, y_train)
        preds = model.predict(X_test_scaled)
        r2 = r2_score(y_test, preds)
        mae = mean_absolute_error(y_test, preds)
        rmse = np.sqrt(mean_squared_error(y_test, preds))
        results[name] = {"r2": r2, "mae": mae, "rmse": rmse}
        print(f"  {name:20s}  R2={r2:.4f}  MAE={mae:.2f}  RMSE={rmse:.2f}")

        if r2 > best_r2:
            best_r2, best_name, best_model = r2, name, model

    print(f"\nBest model: {best_name} (R2={best_r2:.4f})")

    joblib.dump(best_model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    joblib.dump(
        {"columns": feature_columns, "numeric_cols": num_cols_present, "best_model": best_name},
        FEATURES_PATH,
    )

    print(f"\nSaved model      -> {MODEL_PATH}")
    print(f"Saved scaler     -> {SCALER_PATH}")
    print(f"Saved feature meta -> {FEATURES_PATH}")


if __name__ == "__main__":
    main()
