/* ==========================================================================
   EVPulse — app.js
   Handles: theme toggle, loading overlay, dashboard charts, live search +
   sortable/paginated table, CSV/Excel export, Leaflet map, analytics
   charts + correlation heatmap, and the prediction form's AJAX call.
   ========================================================================== */

(function () {
  "use strict";

  // ------------------------------------------------------------------
  // Chart.js global theme sync (colors read from CSS variables)
  // ------------------------------------------------------------------
  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  function chartPalette() {
    return {
      text: cssVar("--text-muted") || "#8A93A8",
      grid: cssVar("--border") || "rgba(255,255,255,.08)",
      blue: cssVar("--accent-blue") || "#3B82F6",
      violet: cssVar("--accent-violet") || "#8B5CF6",
      green: cssVar("--accent-green") || "#14E8B4",
    };
  }

  function baseChartOptions(extra) {
    const p = chartPalette();
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.color = p.text;
    const opts = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: p.text, boxWidth: 12, padding: 14 } },
        tooltip: { backgroundColor: cssVar("--bg-alt") || "#0B111F", titleColor: "#fff", bodyColor: "#fff" },
      },
      scales: {
        x: { ticks: { color: p.text }, grid: { color: p.grid } },
        y: { ticks: { color: p.text }, grid: { color: p.grid } },
      },
    };
    return Object.assign(opts, extra || {});
  }

  function paletteSeries(n) {
    const p = chartPalette();
    const base = [p.blue, p.violet, p.green, "#F59E0B", "#EC4899", "#22D3EE", "#F87171", "#A3E635"];
    const out = [];
    for (let i = 0; i < n; i++) out.push(base[i % base.length]);
    return out;
  }

  // Registry of created chart instances so we can destroy/rebuild on theme change
  const chartInstances = {};
  function renderChart(id, config) {
    const canvas = document.getElementById(id);
    if (!canvas) return;
    if (chartInstances[id]) chartInstances[id].destroy();
    chartInstances[id] = new Chart(canvas.getContext("2d"), config);
  }

  // ------------------------------------------------------------------
  // Theme toggle (persists only in-memory for this session)
  // ------------------------------------------------------------------
  function initTheme() {
    const root = document.documentElement;
    const btn = document.getElementById("themeToggle");
    let theme = window.__evpulseTheme || "dark";
    root.setAttribute("data-theme", theme);

    if (btn) {
      btn.addEventListener("click", () => {
        theme = theme === "dark" ? "light" : "dark";
        window.__evpulseTheme = theme;
        root.setAttribute("data-theme", theme);
        // Redraw charts so colors follow the new theme
        document.dispatchEvent(new CustomEvent("evpulse:themeChanged"));
      });
    }
  }

  function hideLoader() {
    const overlay = document.getElementById("loading-overlay");
    if (overlay) overlay.classList.add("hidden");
  }

  // ------------------------------------------------------------------
  // Small fetch helper
  // ------------------------------------------------------------------
  async function getJSON(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Request failed: ${url}`);
    return res.json();
  }

  // ==================================================================
  // INDEX (Dashboard) PAGE
  // ==================================================================
  function initIndexPage() {
    initTheme();
    loadStatCards();
    loadDashboardCharts();
    initMap();
    initTable();

    document.addEventListener("evpulse:themeChanged", () => {
      loadDashboardCharts();
    });

    hideLoader();
  }

  async function loadStatCards() {
    try {
      const stats = await getJSON("/api/statistics");
      const row = document.getElementById("statCardsRow");
      const cards = [
        { icon: "fa-charging-station", label: "Total Stations", value: stats.total_stations },
        { icon: "fa-city", label: "Cities Covered", value: stats.total_cities },
        { icon: "fa-hourglass-half", label: "Avg. Wait Time (min)", value: stats.avg_waiting_time },
        { icon: "fa-battery-half", label: "Avg. Battery %", value: stats.avg_battery_percentage },
        { icon: "fa-plug-circle-bolt", label: "Avg. Available Chargers", value: stats.avg_available_chargers },
        { icon: "fa-bolt-lightning", label: "Fast Charging Events", value: stats.fast_charging_count },
        { icon: "fa-clock", label: "Normal Charging Events", value: stats.slow_charging_count },
        { icon: "fa-bolt", label: "Avg. Power (kW)", value: stats.avg_charging_power_kw },
      ];
      row.innerHTML = cards.map((c, i) => `
        <div class="col-lg-3 col-md-6">
          <div class="stat-card fade-in" style="animation-delay:${i * 0.05}s">
            <div class="stat-icon"><i class="fa-solid ${c.icon}"></i></div>
            <div class="stat-value">${c.value}</div>
            <div class="stat-label">${c.label}</div>
          </div>
        </div>`).join("");

      const heroWait = document.getElementById("heroAvgWait");
      if (heroWait) heroWait.textContent = stats.avg_waiting_time;
    } catch (e) {
      console.error(e);
    }
  }

  async function loadDashboardCharts() {
    try {
      const c = await getJSON("/api/charts");
      const p = chartPalette();

      renderChart("chartChargingType", {
        type: "doughnut",
        data: {
          labels: Object.keys(c.charging_type),
          datasets: [{ data: Object.values(c.charging_type), backgroundColor: [p.green, p.blue], borderWidth: 0 }],
        },
        options: baseChartOptions({ scales: {} }),
      });

      renderChart("chartVehicleType", {
        type: "pie",
        data: {
          labels: Object.keys(c.vehicle_type),
          datasets: [{ data: Object.values(c.vehicle_type), backgroundColor: paletteSeries(4), borderWidth: 0 }],
        },
        options: baseChartOptions({ scales: {} }),
      });

      renderChart("chartStationsPerCity", {
        type: "bar",
        data: {
          labels: Object.keys(c.stations_per_city),
          datasets: [{ label: "Stations", data: Object.values(c.stations_per_city), backgroundColor: p.blue, borderRadius: 6 }],
        },
        options: baseChartOptions({ plugins: { legend: { display: false } } }),
      });

      renderChart("chartWaitByCity", {
        type: "bar",
        data: {
          labels: Object.keys(c.waiting_by_city),
          datasets: [{ label: "Avg wait (min)", data: Object.values(c.waiting_by_city), backgroundColor: p.violet, borderRadius: 6 }],
        },
        options: baseChartOptions({ indexAxis: "y", plugins: { legend: { display: false } } }),
      });

      renderChart("chartWaitBySlot", {
        type: "line",
        data: {
          labels: Object.keys(c.waiting_by_slot),
          datasets: [{
            label: "Avg wait (min)", data: Object.values(c.waiting_by_slot),
            borderColor: p.green, backgroundColor: hexToRgba(p.green, 0.18),
            fill: true, tension: 0.4, pointBackgroundColor: p.green,
          }],
        },
        options: baseChartOptions({}),
      });
    } catch (e) {
      console.error(e);
    }
  }

  function hexToRgba(hex, alpha) {
    if (!hex.startsWith("#")) return hex;
    const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r},${g},${b},${alpha})`;
  }

  // ------------------------------------------------------------------
  // Leaflet map
  // ------------------------------------------------------------------
  async function initMap() {
    const mapEl = document.getElementById("stationMap");
    if (!mapEl) return;
    const map = L.map("stationMap", { scrollWheelZoom: false }).setView([21.5, 79.0], 5);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap contributors",
    }).addTo(map);

    // Current location control
    const locateBtn = L.control({ position: "topleft" });
    locateBtn.onAdd = function () {
      const div = L.DomUtil.create("div", "leaflet-bar leaflet-control");
      div.innerHTML = `<a href="#" title="My location" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;"><i class="fa-solid fa-location-crosshairs"></i></a>`;
      div.onclick = (e) => {
        e.preventDefault();
        map.locate({ setView: true, maxZoom: 10 });
      };
      return div;
    };
    locateBtn.addTo(map);

    try {
      const data = await getJSON("/api/map");
      const fastIcon = L.divIcon({ className: "", html: `<div style="width:12px;height:12px;border-radius:50%;background:#14E8B4;box-shadow:0 0 0 3px rgba(20,232,180,.25)"></div>` });
      const normalIcon = L.divIcon({ className: "", html: `<div style="width:12px;height:12px;border-radius:50%;background:#3B82F6;box-shadow:0 0 0 3px rgba(59,130,246,.25)"></div>` });

      data.stations.forEach((s) => {
        const icon = s.Charging_Type === "Fast" ? fastIcon : normalIcon;
        L.marker([s.lat, s.lon], { icon }).addTo(map).bindPopup(`
          <div class="map-popup-title">${s.Station_ID} — ${s.City}</div>
          <div class="map-popup-row"><b>Charging Type:</b> ${s.Charging_Type}</div>
          <div class="map-popup-row"><b>Availability:</b> ${s.Available_Chargers}/${s.Total_Chargers} chargers</div>
          <div class="map-popup-row"><b>Avg. Wait Time:</b> ${s.Waiting_Time} min</div>
          <div class="map-popup-row"><b>Vehicle Type:</b> ${s.Vehicle_Type}</div>
        `);
      });
    } catch (e) {
      console.error(e);
    }
  }

  // ------------------------------------------------------------------
  // Table: live search, sort, pagination, export
  // ------------------------------------------------------------------
  const tableState = { q: "", page: 1, per_page: 25, sort_by: "Station_ID", sort_dir: "asc" };
  let searchDebounce = null;

  function initTable() {
    const searchInput = document.getElementById("searchInput");
    if (searchInput) {
      searchInput.addEventListener("input", () => {
        clearTimeout(searchDebounce);
        searchDebounce = setTimeout(() => {
          tableState.q = searchInput.value;
          tableState.page = 1;
          loadTable();
        }, 300);
      });
    }

    document.querySelectorAll("#dataTable thead th[data-col]").forEach((th) => {
      th.addEventListener("click", () => {
        const col = th.getAttribute("data-col");
        if (tableState.sort_by === col) {
          tableState.sort_dir = tableState.sort_dir === "asc" ? "desc" : "asc";
        } else {
          tableState.sort_by = col;
          tableState.sort_dir = "asc";
        }
        loadTable();
      });
    });

    const exportCsv = document.getElementById("exportCsv");
    const exportXlsx = document.getElementById("exportXlsx");
    if (exportCsv) exportCsv.addEventListener("click", () => window.location = `/api/export/csv?q=${encodeURIComponent(tableState.q)}`);
    if (exportXlsx) exportXlsx.addEventListener("click", () => window.location = `/api/export/xlsx?q=${encodeURIComponent(tableState.q)}`);

    loadTable();
  }

  async function loadTable() {
    const tbody = document.getElementById("tableBody");
    const summary = document.getElementById("tableSummary");
    try {
      const params = new URLSearchParams(tableState);
      const data = await getJSON(`/api/data?${params.toString()}`);

      tbody.innerHTML = data.rows.map((r) => `
        <tr>
          <td><strong>${r.Station_ID}</strong></td>
          <td>${r.City}</td>
          <td>${r.Vehicle_Type}</td>
          <td><span class="type-badge ${r.Charging_Type === "Fast" ? "badge-fast" : "badge-normal"}">${r.Charging_Type}</span></td>
          <td>${r.Available_Chargers}</td>
          <td>${r.Total_Chargers}</td>
          <td>${r.Waiting_Time}</td>
          <td>${r.Time_Slot}</td>
        </tr>`).join("") || `<tr><td colspan="8" class="text-center text-muted py-4">No matching stations found.</td></tr>`;

      summary.textContent = `Showing ${data.rows.length ? (data.page - 1) * data.per_page + 1 : 0}–${(data.page - 1) * data.per_page + data.rows.length} of ${data.total} records`;
      renderPagination(data.page, data.total_pages);
    } catch (e) {
      console.error(e);
    }
  }

  function renderPagination(current, totalPages) {
    const el = document.getElementById("pagination");
    if (!el) return;
    let html = "";
    const add = (label, page, disabled, active) => {
      html += `<li class="page-item ${disabled ? "disabled" : ""} ${active ? "active" : ""}">
        <a class="page-link" href="#" data-page="${page}">${label}</a></li>`;
    };
    add("&laquo;", current - 1, current === 1, false);
    const start = Math.max(1, current - 2);
    const end = Math.min(totalPages, start + 4);
    for (let p = start; p <= end; p++) add(p, p, false, p === current);
    add("&raquo;", current + 1, current === totalPages, false);
    el.innerHTML = html;

    el.querySelectorAll("a.page-link").forEach((a) => {
      a.addEventListener("click", (e) => {
        e.preventDefault();
        const page = parseInt(a.getAttribute("data-page"), 10);
        if (!page || page < 1 || page > totalPages) return;
        tableState.page = page;
        loadTable();
        document.getElementById("dataTable").scrollIntoView({ behavior: "smooth", block: "nearest" });
      });
    });
  }

  // ==================================================================
  // ANALYTICS PAGE
  // ==================================================================
  function initAnalyticsPage() {
    initTheme();
    loadQualityCards();
    loadAnalyticsCharts();
    document.addEventListener("evpulse:themeChanged", loadAnalyticsCharts);
    hideLoader();
  }

  async function loadQualityCards() {
    try {
      const stats = await getJSON("/api/statistics");
      const row = document.getElementById("qualityCardsRow");
      const missingCount = Object.keys(stats.missing_values).length;
      const cards = [
        { icon: "fa-database", label: "Total Records", value: stats.total_records },
        { icon: "fa-triangle-exclamation", label: "Columns with Missing Values", value: missingCount },
        { icon: "fa-clone", label: "Duplicate Rows", value: stats.duplicate_rows },
        { icon: "fa-bolt", label: "Avg. Electricity Load", value: stats.avg_electricity_load },
      ];
      row.innerHTML = cards.map((c, i) => `
        <div class="col-lg-3 col-md-6">
          <div class="stat-card fade-in" style="animation-delay:${i * 0.05}s">
            <div class="stat-icon"><i class="fa-solid ${c.icon}"></i></div>
            <div class="stat-value">${c.value}</div>
            <div class="stat-label">${c.label}</div>
          </div>
        </div>`).join("");
    } catch (e) {
      console.error(e);
    }
  }

  async function loadAnalyticsCharts() {
    try {
      const c = await getJSON("/api/charts");
      const p = chartPalette();

      renderChart("chartHistogram", {
        type: "bar",
        data: {
          labels: c.histogram.labels,
          datasets: [{ label: "Events", data: c.histogram.values, backgroundColor: p.blue, borderRadius: 4 }],
        },
        options: baseChartOptions({ plugins: { legend: { display: false } } }),
      });

      renderChart("chartTrafficRadar", {
        type: "radar",
        data: {
          labels: Object.keys(c.traffic_level),
          datasets: [{
            label: "Events", data: Object.values(c.traffic_level),
            borderColor: p.violet, backgroundColor: hexToRgba(p.violet, 0.25), pointBackgroundColor: p.violet,
          }],
        },
        options: baseChartOptions({
          scales: {
            r: { ticks: { color: p.text, backdropColor: "transparent" }, grid: { color: p.grid }, angleLines: { color: p.grid } },
          },
        }),
      });

      renderChart("chartWeather", {
        type: "polarArea",
        data: {
          labels: Object.keys(c.weather_dist),
          datasets: [{ data: Object.values(c.weather_dist), backgroundColor: paletteSeries(3).map(x => hexToRgba(x, 0.55)) }],
        },
        options: baseChartOptions({ scales: { r: { ticks: { color: p.text, backdropColor: "transparent" }, grid: { color: p.grid } } } }),
      });

      renderChart("chartTopStations", {
        type: "bar",
        data: {
          labels: c.top_stations.map(s => s.Station_ID),
          datasets: [{ label: "Avg wait (min)", data: c.top_stations.map(s => s.avg_wait), backgroundColor: p.green, borderRadius: 6 }],
        },
        options: baseChartOptions({ indexAxis: "y", plugins: { legend: { display: false } } }),
      });

      renderHeatmap(c.correlation);
    } catch (e) {
      console.error(e);
    }
  }

  function renderHeatmap(correlation) {
    const table = document.getElementById("heatmapTable");
    if (!table) return;
    const labels = correlation.labels;
    const matrix = correlation.matrix;

    let html = "<thead><tr><th></th>" + labels.map(l => `<th>${l}</th>`).join("") + "</tr></thead><tbody>";
    matrix.forEach((row, i) => {
      html += `<tr><th>${labels[i]}</th>`;
      row.forEach((val) => {
        const intensity = Math.abs(val);
        const color = val >= 0
          ? `rgba(20,232,180,${intensity})`
          : `rgba(248,113,113,${intensity})`;
        html += `<td style="background:${color}; color:${intensity > 0.5 ? '#06110d' : 'inherit'}">${val.toFixed(2)}</td>`;
      });
      html += "</tr>";
    });
    html += "</tbody>";
    table.innerHTML = html;
  }

  // ==================================================================
  // PREDICTION PAGE
  // ==================================================================
  function initPredictionPage() {
    initTheme();
    hideLoader();

    const form = document.getElementById("predictForm");
    if (!form) return;

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const submitBtn = form.querySelector("button[type=submit]");
      const originalHtml = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>Predicting…`;

      try {
        const formData = new FormData(form);
        const payload = Object.fromEntries(formData.entries());

        const res = await fetch("/api/predict", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (!res.ok) throw new Error("Prediction failed");
        const result = await res.json();
        showPredictionResult(result);
      } catch (err) {
        console.error(err);
        alert("Something went wrong while predicting. Please check your inputs and try again.");
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalHtml;
      }
    });
  }

  function showPredictionResult(result) {
    document.getElementById("resultPlaceholder").classList.add("d-none");
    const content = document.getElementById("resultContent");
    content.classList.remove("d-none");

    document.getElementById("predValue").textContent = result.predicted_waiting_time;
    document.getElementById("demandBadge").textContent = `${result.demand_level} Demand`;
    document.getElementById("modelUsed").textContent = result.model_used;

    const confBar = document.getElementById("confBar");
    const confValue = document.getElementById("confValue");
    confValue.textContent = `${result.confidence_score}%`;
    requestAnimationFrame(() => { confBar.style.width = `${result.confidence_score}%`; });
  }

  // Expose entry points used by inline <script> blocks in templates
  window.EVPulse = { initIndexPage, initAnalyticsPage, initPredictionPage };
})();
